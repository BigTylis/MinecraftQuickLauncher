local Manifest = GetManifest()
local VideoTime = GetVideoPlayback("time")

print(VideoTime)
print(Manifest)
--[[
LoadBackgroundVideo("", true)
SetVideoPlayback(nil, 1)
SetBackgroundOverlay(GradientOverlayParams.New(Manifest.SolidGradientColor1, Manifest.SolidGradientColor2, Manifest.SolidGradientTransparency1, Manifest.SolidGradientTransparency2))
wait(2)
MessageBox("DONE")
print("e")
SetBackgroundFrame(0, "this/blackguysleep.jpg")
PlaySound("this/Bruh.mp3", true)]]